//
//  ViewController.swift
//  SpeechRecognizer
//
//  Created by S. M. Hasibur Rahman on 11/23/19.
//  Copyright © 2019 S. M. Hasibur Rahman. All rights reserved.
//

import UIKit
import Speech

class ViewController: UIViewController, SFSpeechRecognizerDelegate{

    @IBOutlet weak var startButton: UIButton!
    
    var isRecording: Bool = false
    let audioEngine = AVAudioEngine()
    let speechRecognizer: SFSpeechRecognizer? = SFSpeechRecognizer()
    let request = SFSpeechAudioBufferRecognitionRequest()
    var recognitionTask: SFSpeechRecognitionTask?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        requestSpeechAuthorization()
    }


    @IBAction func startButtonTapped(_ sender: Any) {
        if isRecording == true {
            cancelRecording()
            isRecording = false
            startButton.backgroundColor = UIColor.gray
        } else {
            self.recordAndRecognizeSpeech()
            isRecording = true
            startButton.backgroundColor = UIColor.red
        }
    }
    
    func cancelRecording() {
           recognitionTask?.finish()
           recognitionTask = nil
           
           // stop audio
           request.endAudio()
           audioEngine.stop()
           audioEngine.inputNode.removeTap(onBus: 0)
       }
    
    //MARK: - Recognize Speech
    func recordAndRecognizeSpeech() {
        let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.request.append(buffer)
        }
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
//            self.sendAlert(title: "Speech Recognizer Error", message: "There has been an audio engine error.")
            return print(error)
        }
        guard let myRecognizer = SFSpeechRecognizer() else {
//            self.sendAlert(title: "Speech Recognizer Error", message: "Speech recognition is not supported for your current locale.")
            return
        }
        if !myRecognizer.isAvailable {
//            self.sendAlert(title: "Speech Recognizer Error", message: "Speech recognition is not currently available. Check back at a later time.")
            // Recognizer is not available right now
            return
        }
        recognitionTask = speechRecognizer?.recognitionTask(with: request, resultHandler: { result, error in
            if let result = result {
                
                let bestString = result.bestTranscription.formattedString
                var lastString: String = ""
                for segment in result.bestTranscription.segments {
                    let indexTo = bestString.index(bestString.startIndex, offsetBy: segment.substringRange.location)
                    lastString = String(bestString[indexTo...])
                    print("result1")
                    print(lastString)
                }
                //self.checkForColorsSaid(resultString: lastString)
                print("result2")
            } else if let error = error {
                //self.sendAlert(title: "Speech Recognizer Error", message: "There has been a speech recognition error.")
                print(error)
                print("result3")
            }
        })
    }
    
    //MARK: - Check Authorization Status
    func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized:
                    self.startButton.isEnabled = true
                    print("autorized")
                case .denied:
                    self.startButton.isEnabled = false
                    print("User denied access to speech recognition")
                case .restricted:
                    self.startButton.isEnabled = false
                    print("Speech recognition restricted on this device")
                case .notDetermined:
                    self.startButton.isEnabled = false
                    print("Speech recognition not yet authorized")
                @unknown default:
                    return
                }
            }
        }
    }
    
    
}


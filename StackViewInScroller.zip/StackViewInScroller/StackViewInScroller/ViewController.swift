//
//  ViewController.swift
//  StackViewInScroller
//
//  Created by S. M. Hasibur Rahman on 11/20/19.
//  Copyright © 2019 S. M. Hasibur Rahman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //scrollView.backgroundColor = .gray
        //print(scrollView.contentOffset)
    }


}


//
//  TodoTask.swift
//  TodoApp
//
//  Created by S. M.Hasibur Rahman on 24/5/19.
//  Copyright © 2019 S. M. Hasibur Rahman. All rights reserved.
//

import UIKit

class TodoTask {
    var name = ""
    var isImportant = false
}
